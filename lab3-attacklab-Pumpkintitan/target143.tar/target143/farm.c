/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_467()
{
    return 2421736015U;
}

unsigned getval_188()
{
    return 3281031192U;
}

unsigned addval_491(unsigned x)
{
    return x + 3284633920U;
}

unsigned addval_241(unsigned x)
{
    return x + 3351468169U;
}

unsigned addval_324(unsigned x)
{
    return x + 3284631880U;
}

void setval_146(unsigned *p)
{
    *p = 1405319251U;
}

unsigned addval_362(unsigned x)
{
    return x + 3347662875U;
}

unsigned getval_109()
{
    return 3347662994U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_406(unsigned x)
{
    return x + 3373845129U;
}

unsigned getval_488()
{
    return 3380926089U;
}

unsigned getval_312()
{
    return 3767093417U;
}

unsigned getval_130()
{
    return 3281114761U;
}

unsigned addval_136(unsigned x)
{
    return x + 3523267209U;
}

unsigned addval_465(unsigned x)
{
    return x + 3229928073U;
}

unsigned addval_458(unsigned x)
{
    return x + 3286280520U;
}

unsigned getval_428()
{
    return 3374891401U;
}

void setval_221(unsigned *p)
{
    *p = 3223377545U;
}

unsigned addval_417(unsigned x)
{
    return x + 3286272320U;
}

unsigned getval_323()
{
    return 3677935257U;
}

void setval_137(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_189(unsigned x)
{
    return x + 3677929881U;
}

unsigned addval_159(unsigned x)
{
    return x + 3373845129U;
}

void setval_264(unsigned *p)
{
    *p = 3281046157U;
}

unsigned addval_498(unsigned x)
{
    return x + 3264268937U;
}

unsigned addval_297(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_421()
{
    return 3281043849U;
}

unsigned getval_347()
{
    return 3534018185U;
}

unsigned addval_395(unsigned x)
{
    return x + 3353381192U;
}

void setval_262(unsigned *p)
{
    *p = 2425542281U;
}

unsigned addval_220(unsigned x)
{
    return x + 3374367129U;
}

void setval_101(unsigned *p)
{
    *p = 3281049289U;
}

void setval_358(unsigned *p)
{
    *p = 3525362073U;
}

unsigned addval_116(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_442()
{
    return 3676883593U;
}

void setval_256(unsigned *p)
{
    *p = 3372796553U;
}

void setval_403(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_118(unsigned x)
{
    return x + 3229925801U;
}

unsigned getval_407()
{
    return 3677410953U;
}

unsigned addval_446(unsigned x)
{
    return x + 3526934921U;
}

unsigned getval_455()
{
    return 2428619103U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
